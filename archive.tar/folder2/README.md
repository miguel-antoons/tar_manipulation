# tar_manipulation
Set of C functions that allows the user to manipulate .tar files.
